import { CommonModule } from './../common/common.module';
import { UserModule } from './../user/user.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from '../user/models/user.entity';
import { UserService } from './../user/user.service';
import { Module } from '@nestjs/common';
import { AuthController } from './auth.controller';
import { JwtModule } from '@nestjs/jwt';


@Module({
  imports:[TypeOrmModule.forFeature([User]),UserModule,
  CommonModule
  ],
  controllers: [AuthController],
  providers:[UserService]
})
export class AuthModule {}
