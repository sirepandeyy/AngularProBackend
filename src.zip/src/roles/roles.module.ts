import { TypeOrmModule } from '@nestjs/typeorm';
import { Role } from './role.entity';
import { Module } from '@nestjs/common';
import { RolesController } from './roles.controller';
import { RoleService } from './roles.service';

@Module({
  imports:[TypeOrmModule.forFeature([Role])],
  controllers: [RolesController],
  providers: [RoleService]
})
export class RolesModule {}
