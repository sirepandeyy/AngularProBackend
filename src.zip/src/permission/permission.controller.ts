import { PermissionService } from './permission.service';
import { AuthGuard } from './../auth/auth.guard';
import { UseGuards, Controller, Get } from '@nestjs/common';
@UseGuards(AuthGuard)
@Controller('permissions')
export class PermissionController {
    constructor(private permissionService: PermissionService) {
    }

    @Get()
    async all() {
        return this.permissionService.all();
    }
}